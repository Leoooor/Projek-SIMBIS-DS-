// ── Export Utilities ─────────────────────────────────────────────────────────
// Uses SheetJS (xlsx) loaded via CDN in index.html

/**
 * Export products + salesHistory to Excel (.xlsx) with two sheets.
 */
export function exportToExcel(db) {
  const XLSX = window.XLSX;
  if (!XLSX) { alert("Library XLSX belum tersedia. Coba refresh halaman."); return; }

  const wb = XLSX.utils.book_new();

  // Sheet 1 — Products
  const productRows = db.products.map((p) => ({
    ID:         p.id,
    Nama:       p.name,
    Kategori:   p.category,
    Harga:      p.price,
    Stok:       p.stock,
    "Tren (0-100)": p.trend,
    Status:     p.status,
  }));
  const wsProducts = XLSX.utils.json_to_sheet(productRows);
  wsProducts["!cols"] = [
    { wch: 6 }, { wch: 24 }, { wch: 16 }, { wch: 14 },
    { wch: 8  }, { wch: 14 }, { wch: 12 },
  ];
  XLSX.utils.book_append_sheet(wb, wsProducts, "Produk");

  // Sheet 2 — Sales History
  const salesRows = db.salesHistory.map((s) => ({
    Bulan:              s.month,
    Penjualan:          s.penjualan,
    Stok:               s.stok,
    "Prediksi Permintaan": s.permintaan,
    "Gap (Permintaan-Penjualan)": s.permintaan - s.penjualan,
  }));
  const wsSales = XLSX.utils.json_to_sheet(salesRows);
  wsSales["!cols"] = [
    { wch: 8 }, { wch: 12 }, { wch: 8 }, { wch: 22 }, { wch: 26 },
  ];
  XLSX.utils.book_append_sheet(wb, wsSales, "Riwayat Penjualan");

  const date = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(wb, `DemandPredict_${date}.xlsx`);
}

/**
 * Export a single dataset to CSV.
 * type: "products" | "sales"
 */
export function exportToCSV(db, type = "products") {
  const XLSX = window.XLSX;
  if (!XLSX) { alert("Library XLSX belum tersedia."); return; }

  let rows;
  let filename;

  if (type === "products") {
    rows = db.products.map((p) => ({
      ID: p.id, Nama: p.name, Kategori: p.category,
      Harga: p.price, Stok: p.stock, Tren: p.trend, Status: p.status,
    }));
    filename = `DemandPredict_Produk_${new Date().toISOString().slice(0,10)}.csv`;
  } else {
    rows = db.salesHistory.map((s) => ({
      Bulan: s.month, Penjualan: s.penjualan, Stok: s.stok,
      PrediksiPermintaan: s.permintaan,
    }));
    filename = `DemandPredict_Penjualan_${new Date().toISOString().slice(0,10)}.csv`;
  }

  const ws = XLSX.utils.json_to_sheet(rows);
  const csv = XLSX.utils.sheet_to_csv(ws);

  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

/**
 * Generate a JSON string of all data (for Google Drive backup).
 */
export function dataToJSON(db) {
  return JSON.stringify(db, null, 2);
}
