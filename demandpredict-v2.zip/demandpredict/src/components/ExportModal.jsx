import { useState } from "react";
import { exportToExcel, exportToCSV, dataToJSON } from "../export";

// ── Google Drive Upload via Google Picker / REST API ─────────────────────────
// Requires VITE_GOOGLE_CLIENT_ID in .env
const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID || "";
const SCOPES = "https://www.googleapis.com/auth/drive.file";

function loadGoogleScript() {
  return new Promise((resolve) => {
    if (window.google?.accounts) { resolve(); return; }
    const s = document.createElement("script");
    s.src = "https://accounts.google.com/gsi/client";
    s.onload = resolve;
    document.head.appendChild(s);
  });
}

async function uploadToDrive(json, onStatus) {
  if (!GOOGLE_CLIENT_ID) {
    onStatus("error", "Google Client ID belum dikonfigurasi. Tambahkan VITE_GOOGLE_CLIENT_ID di file .env");
    return;
  }

  onStatus("loading", "Memuat Google Sign-In...");
  await loadGoogleScript();

  return new Promise((resolve) => {
    const tokenClient = window.google.accounts.oauth2.initTokenClient({
      client_id: GOOGLE_CLIENT_ID,
      scope: SCOPES,
      callback: async (response) => {
        if (response.error) {
          onStatus("error", "Gagal otorisasi Google: " + response.error);
          resolve();
          return;
        }
        const token  = response.access_token;
        const date   = new Date().toISOString().slice(0, 10);
        const filename = `DemandPredict_Backup_${date}.json`;

        onStatus("loading", "Mengunggah ke Google Drive...");

        try {
          const meta = new Blob([JSON.stringify({ name: filename, mimeType: "application/json" })],
            { type: "application/json" });
          const body = new Blob([json], { type: "application/json" });

          const form = new FormData();
          form.append("metadata", meta);
          form.append("file",     body);

          const res = await fetch(
            "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
            { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: form }
          );

          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          const data = await res.json();
          onStatus("success", `✓ Berhasil diunggah: "${data.name}" ke Google Drive!`);
        } catch (e) {
          onStatus("error", "Gagal unggah: " + e.message);
        }
        resolve();
      },
    });
    tokenClient.requestAccessToken({ prompt: "consent" });
  });
}

// ── Component ────────────────────────────────────────────────────────────────
export default function ExportModal({ db, onClose }) {
  const [driveStatus, setDriveStatus] = useState({ type: "", msg: "" });
  const [driveLoading, setDriveLoading] = useState(false);

  const onDriveStatus = (type, msg) => {
    setDriveStatus({ type, msg });
    setDriveLoading(type === "loading");
  };

  const handleDrive = async () => {
    setDriveLoading(true);
    setDriveStatus({ type: "loading", msg: "Menghubungi Google..." });
    await uploadToDrive(dataToJSON(db), onDriveStatus);
    setDriveLoading(false);
  };

  const btnBase = `flex items-center gap-3 w-full px-4 py-3 rounded-xl border text-sm
    transition-all text-left`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4">
      <div className="bg-[#0d1221] border border-slate-800/60 rounded-2xl w-full max-w-md shadow-2xl"
           style={{ fontFamily: "'IBM Plex Mono', monospace" }}>

        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800/60">
          <div>
            <div style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                 className="text-white font-semibold text-base">Export & Backup Data</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Unduh atau simpan ke cloud</div>
          </div>
          <button onClick={onClose}
            className="text-slate-500 hover:text-white text-xl transition-colors">✕</button>
        </div>

        <div className="p-5 space-y-3">

          {/* Excel */}
          <div className="bg-slate-900/40 rounded-xl border border-slate-800/40 p-4">
            <div className="text-[10px] text-slate-500 uppercase tracking-widest mb-3">
              📊 Excel (.xlsx) — Multi-sheet
            </div>
            <button onClick={() => exportToExcel(db)}
              className={`${btnBase} bg-emerald-500/10 hover:bg-emerald-500/20
                border-emerald-500/30 text-emerald-300`}>
              <span className="text-lg">📗</span>
              <div>
                <div className="font-medium text-sm">Export Semua Data ke Excel</div>
                <div className="text-[10px] text-emerald-400/70 mt-0.5">
                  Sheet: Produk + Riwayat Penjualan
                </div>
              </div>
            </button>
          </div>

          {/* CSV */}
          <div className="bg-slate-900/40 rounded-xl border border-slate-800/40 p-4">
            <div className="text-[10px] text-slate-500 uppercase tracking-widest mb-3">
              📄 CSV — Spreadsheet kompatibel
            </div>
            <div className="space-y-2">
              <button onClick={() => exportToCSV(db, "products")}
                className={`${btnBase} bg-amber-500/10 hover:bg-amber-500/20
                  border-amber-500/30 text-amber-300`}>
                <span>📦</span>
                <div>
                  <div className="font-medium text-sm">CSV — Data Produk</div>
                  <div className="text-[10px] text-amber-400/70">{db.products.length} produk</div>
                </div>
              </button>
              <button onClick={() => exportToCSV(db, "sales")}
                className={`${btnBase} bg-amber-500/10 hover:bg-amber-500/20
                  border-amber-500/30 text-amber-300`}>
                <span>📈</span>
                <div>
                  <div className="font-medium text-sm">CSV — Riwayat Penjualan</div>
                  <div className="text-[10px] text-amber-400/70">
                    {db.salesHistory.length} bulan
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* Google Drive */}
          <div className="bg-slate-900/40 rounded-xl border border-slate-800/40 p-4">
            <div className="text-[10px] text-slate-500 uppercase tracking-widest mb-3">
              ☁️ Google Drive — Backup Online
            </div>
            <button onClick={handleDrive} disabled={driveLoading}
              className={`${btnBase} bg-sky-500/10 hover:bg-sky-500/20
                border-sky-500/30 text-sky-300 disabled:opacity-50 disabled:cursor-not-allowed`}>
              <span className="text-lg">🔵</span>
              <div>
                <div className="font-medium text-sm">
                  {driveLoading ? "Menghubungkan..." : "Simpan Backup ke Google Drive"}
                </div>
                <div className="text-[10px] text-sky-400/70 mt-0.5">
                  Format JSON — butuh akun Google & Client ID
                </div>
              </div>
            </button>

            {driveStatus.msg && (
              <div className={`mt-3 text-xs px-3 py-2 rounded-lg border
                ${driveStatus.type === "success"
                  ? "bg-emerald-900/20 border-emerald-800/30 text-emerald-300"
                  : driveStatus.type === "error"
                  ? "bg-red-900/20 border-red-800/30 text-red-300"
                  : "bg-sky-900/20 border-sky-800/30 text-sky-300"}`}>
                {driveStatus.msg}
              </div>
            )}

            {!GOOGLE_CLIENT_ID && (
              <div className="mt-2 text-[10px] text-slate-600 leading-relaxed">
                ⚠ Tambahkan <code className="text-slate-400">VITE_GOOGLE_CLIENT_ID</code> di
                file <code className="text-slate-400">.env</code> untuk mengaktifkan fitur ini.
              </div>
            )}
          </div>
        </div>

        <div className="px-5 pb-5">
          <button onClick={onClose}
            className="w-full text-xs text-slate-500 hover:text-slate-300 py-2 transition-colors">
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
}
