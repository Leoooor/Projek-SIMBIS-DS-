import { useState } from "react";
import { login, register } from "../auth";

export default function LoginPage({ onLogin }) {
  const [mode, setMode]       = useState("login"); // "login" | "register"
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName]         = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [error, setError]       = useState("");
  const [success, setSuccess]   = useState("");
  const [loading, setLoading]   = useState(false);

  const reset = () => {
    setError(""); setSuccess("");
    setUsername(""); setPassword(""); setName(""); setConfirmPw("");
  };

  const handleLogin = () => {
    setError("");
    if (!username || !password) { setError("Username dan password wajib diisi."); return; }
    setLoading(true);
    setTimeout(() => {
      const session = login(username, password);
      setLoading(false);
      if (!session) { setError("Username atau password salah."); return; }
      onLogin(session);
    }, 400);
  };

  const handleRegister = () => {
    setError(""); setSuccess("");
    if (!username || !password || !name) { setError("Semua kolom wajib diisi."); return; }
    if (password !== confirmPw) { setError("Konfirmasi password tidak cocok."); return; }
    if (password.length < 6)   { setError("Password minimal 6 karakter."); return; }
    setLoading(true);
    setTimeout(() => {
      const ok = register(username, password, name);
      setLoading(false);
      if (!ok) { setError("Username sudah digunakan."); return; }
      setSuccess("Akun berhasil dibuat! Silakan login.");
      setMode("login");
      setUsername(username); setPassword("");
    }, 400);
  };

  const fieldClass = `w-full bg-[#0a0e1a] border border-slate-700/60 text-slate-100 text-sm
    rounded-lg px-4 py-2.5 focus:outline-none focus:border-sky-500/60 transition-colors
    placeholder:text-slate-600`;

  return (
    <div className="min-h-screen bg-[#0a0e1a] flex items-center justify-center px-4"
         style={{ fontFamily: "'IBM Plex Mono', monospace" }}>

      {/* Background glow */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2
                        w-[600px] h-[400px] bg-sky-500/5 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-sm relative">
        {/* Logo / Brand */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="text-sky-400 text-2xl">◈</span>
            <span style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                  className="text-white font-bold text-xl tracking-tight">
              DemandPredict
            </span>
          </div>
          <p className="text-[11px] text-slate-500 tracking-widest uppercase">
            Platform Prediksi Permintaan UMKM
          </p>
        </div>

        {/* Card */}
        <div className="bg-[#0d1221] border border-slate-800/60 rounded-2xl p-6 shadow-2xl">
          {/* Tab switcher */}
          <div className="flex mb-6 bg-slate-900/60 rounded-lg p-1">
            {["login", "register"].map((m) => (
              <button key={m}
                onClick={() => { setMode(m); reset(); }}
                className={`flex-1 text-xs py-2 rounded-md transition-all capitalize
                  ${mode === m
                    ? "bg-sky-500/20 text-sky-300 border border-sky-500/30"
                    : "text-slate-500 hover:text-slate-300"}`}>
                {m === "login" ? "Masuk" : "Daftar"}
              </button>
            ))}
          </div>

          {/* Error / Success */}
          {error && (
            <div className="mb-4 text-xs text-red-400 bg-red-900/20 border border-red-800/30
                            rounded-lg px-3 py-2">
              ⚠ {error}
            </div>
          )}
          {success && (
            <div className="mb-4 text-xs text-emerald-400 bg-emerald-900/20 border border-emerald-800/30
                            rounded-lg px-3 py-2">
              ✓ {success}
            </div>
          )}

          <div className="space-y-3">
            {mode === "register" && (
              <div>
                <label className="text-[10px] text-slate-500 uppercase tracking-widest mb-1 block">
                  Nama Lengkap
                </label>
                <input className={fieldClass} placeholder="contoh: Budi Santoso"
                  value={name} onChange={(e) => setName(e.target.value)} />
              </div>
            )}

            <div>
              <label className="text-[10px] text-slate-500 uppercase tracking-widest mb-1 block">
                Username
              </label>
              <input className={fieldClass} placeholder="username"
                value={username} onChange={(e) => setUsername(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (mode === "login" ? handleLogin() : null)} />
            </div>

            <div>
              <label className="text-[10px] text-slate-500 uppercase tracking-widest mb-1 block">
                Password
              </label>
              <input className={fieldClass} type="password" placeholder="••••••••"
                value={password} onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (mode === "login" ? handleLogin() : null)} />
            </div>

            {mode === "register" && (
              <div>
                <label className="text-[10px] text-slate-500 uppercase tracking-widest mb-1 block">
                  Konfirmasi Password
                </label>
                <input className={fieldClass} type="password" placeholder="••••••••"
                  value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} />
              </div>
            )}

            <button
              onClick={mode === "login" ? handleLogin : handleRegister}
              disabled={loading}
              className="w-full mt-2 bg-sky-500/20 hover:bg-sky-500/30 border border-sky-500/40
                         text-sky-300 text-sm py-2.5 rounded-lg transition-all
                         disabled:opacity-50 disabled:cursor-not-allowed">
              {loading ? "⏳ Memproses..." : mode === "login" ? "Masuk →" : "Buat Akun →"}
            </button>
          </div>

          {mode === "login" && (
            <p className="text-center text-[10px] text-slate-600 mt-4">
              Default: <span className="text-slate-400">admin</span> /
              <span className="text-slate-400"> admin123</span>
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
