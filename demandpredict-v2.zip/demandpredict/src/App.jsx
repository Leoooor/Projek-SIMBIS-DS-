import { useState, useEffect } from "react";
import { loadData, saveData } from "./storage";
import { NAV_ITEMS } from "./utils";
import { getSession, logout } from "./auth";

import Sidebar       from "./components/Sidebar";
import Toast         from "./components/Toast";
import ProductModal  from "./components/ProductModal";
import DeleteConfirm from "./components/DeleteConfirm";
import ExportModal   from "./components/ExportModal";
import LoginPage     from "./pages/Login";

import Dashboard    from "./pages/Dashboard";
import Products     from "./pages/Products";
import Analytics    from "./pages/Analytics";
import AIConsultant from "./pages/AIConsultant";
import Alerts       from "./pages/Alerts";

export default function App() {
  const [session, setSession]           = useState(() => getSession());
  const [db, setDb]                     = useState(loadData);
  const [page, setPage]                 = useState("dashboard");
  const [showForm, setShowForm]         = useState(false);
  const [editItem, setEditItem]         = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [notification, setNotification] = useState(null);
  const [sidebarOpen, setSidebarOpen]   = useState(false);
  const [showExport, setShowExport]     = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  useEffect(() => { saveData(db); }, [db]);

  useEffect(() => {
    if (!showUserMenu) return;
    const handler = () => setShowUserMenu(false);
    document.addEventListener("click", handler);
    return () => document.removeEventListener("click", handler);
  }, [showUserMenu]);

  const handleLogin  = (s) => setSession(s);
  const handleLogout = () => { logout(); setSession(null); };

  if (!session) return <LoginPage onLogin={handleLogin} />;

  const notify = (msg, type = "success") => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const openAdd  = () => { setEditItem(null); setShowForm(true); };
  const openEdit = (product) => { setEditItem(product); setShowForm(true); };

  const handleSubmitProduct = (formData) => {
    setDb((prev) => {
      if (editItem) {
        return { ...prev, products: prev.products.map((p) => p.id === editItem.id ? { ...p, ...formData } : p) };
      }
      return { ...prev, products: [...prev.products, { id: prev.nextId, ...formData }], nextId: prev.nextId + 1 };
    });
    notify(editItem ? "Produk diperbarui!" : "Produk ditambahkan!");
    setShowForm(false); setEditItem(null);
  };

  const handleDeleteProduct = (id) => {
    setDb((prev) => ({ ...prev, products: prev.products.filter((p) => p.id !== id) }));
    notify("Produk dihapus.", "info");
    setDeleteTarget(null);
  };

  const dismissAlert     = (id) => setDb((prev) => ({ ...prev, alerts: prev.alerts.filter((a) => a.id !== id) }));
  const dismissAllAlerts = () => { setDb((prev) => ({ ...prev, alerts: [] })); notify("Semua notifikasi dihapus.", "info"); };

  const navigate     = (id) => { setPage(id); setSidebarOpen(false); };
  const currentLabel = NAV_ITEMS.find((n) => n.id === page)?.label ?? "";

  return (
    <div style={{ fontFamily: "'IBM Plex Mono', monospace" }} className="min-h-screen bg-[#0a0e1a] text-slate-100 flex">

      <div className="hidden lg:flex">
        <Sidebar page={page} onNavigate={navigate} alertCount={db.alerts.length} />
      </div>

      {sidebarOpen && (
        <>
          <div className="fixed inset-0 z-30 bg-black/50 backdrop-blur-sm lg:hidden"
               onClick={() => setSidebarOpen(false)} />
          <div className="fixed inset-y-0 left-0 z-40 lg:hidden">
            <Sidebar page={page} onNavigate={navigate} alertCount={db.alerts.length} />
          </div>
        </>
      )}

      <main className="flex-1 flex flex-col min-w-0">
        <header className="h-14 bg-[#0d1221]/80 border-b border-slate-800/60 flex items-center px-5 gap-4 sticky top-0 z-20 backdrop-blur">
          <button className="lg:hidden text-slate-400 hover:text-white text-xl"
                  onClick={() => setSidebarOpen(true)}>☰</button>

          <div className="flex-1">
            <span style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                  className="text-sm font-semibold text-white">{currentLabel}</span>
          </div>

          <button
            onClick={() => setShowExport(true)}
            className="flex items-center gap-1.5 text-[10px] text-emerald-300 bg-emerald-500/10
                       hover:bg-emerald-500/20 border border-emerald-500/30 px-3 py-1.5 rounded-lg
                       transition-all uppercase tracking-widest">
            ↓ Export
          </button>

          <div className="text-[10px] text-slate-500 tracking-widest uppercase hidden sm:block">
            {new Date().toLocaleDateString("id-ID", { weekday: "short", day: "numeric", month: "short", year: "numeric" })}
          </div>

          <div className="relative">
            <button
              onClick={(e) => { e.stopPropagation(); setShowUserMenu((v) => !v); }}
              className="flex items-center gap-2 bg-slate-800/60 hover:bg-slate-700/60 border border-slate-700/40
                         rounded-lg px-3 py-1.5 text-xs transition-all">
              <span className="w-5 h-5 rounded-full bg-sky-500/30 border border-sky-500/40
                               flex items-center justify-center text-[10px] text-sky-300 font-bold">
                {session.name?.[0]?.toUpperCase() ?? "U"}
              </span>
              <span className="text-slate-300 hidden sm:block">{session.name}</span>
              <span className="text-slate-500 text-[10px]">▾</span>
            </button>

            {showUserMenu && (
              <div className="absolute right-0 top-10 w-48 bg-[#0d1221] border border-slate-800/60
                              rounded-xl shadow-2xl z-50 overflow-hidden"
                   onClick={(e) => e.stopPropagation()}>
                <div className="px-4 py-3 border-b border-slate-800/60">
                  <div className="text-xs text-white font-medium">{session.name}</div>
                  <div className="text-[10px] text-slate-500">@{session.username}</div>
                  <div className="text-[10px] text-sky-400 mt-0.5 capitalize">{session.role}</div>
                </div>
                <button onClick={handleLogout}
                  className="w-full text-left px-4 py-3 text-xs text-red-400 hover:bg-red-900/20 transition-colors">
                  ⏻ Keluar
                </button>
              </div>
            )}
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-5">
          {page === "dashboard" && <Dashboard    db={db} />}
          {page === "products"  && <Products     db={db} onAdd={openAdd} onEdit={openEdit} onDelete={setDeleteTarget} />}
          {page === "analytics" && <Analytics    db={db} />}
          {page === "ai"        && <AIConsultant db={db} />}
          {page === "alerts"    && <Alerts       db={db} onDismiss={dismissAlert} onDismissAll={dismissAllAlerts} />}
        </div>
      </main>

      <Toast notification={notification} />

      {showExport && <ExportModal db={db} onClose={() => setShowExport(false)} />}

      {showForm && (
        <ProductModal
          editItem={editItem}
          onClose={() => { setShowForm(false); setEditItem(null); }}
          onSubmit={handleSubmitProduct}
          onNotify={notify}
        />
      )}

      {deleteTarget !== null && (
        <DeleteConfirm
          onConfirm={() => handleDeleteProduct(deleteTarget)}
          onCancel={() => setDeleteTarget(null)}
        />
      )}
    </div>
  );
}
