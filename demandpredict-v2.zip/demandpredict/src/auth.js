// ── Auth helpers ────────────────────────────────────────────────────────────
const AUTH_KEY   = "demandpredict_auth";
const USERS_KEY  = "demandpredict_users";

// Default admin account
const DEFAULT_USERS = [
  { username: "admin", password: "admin123", name: "Administrator", role: "admin" },
];

export function getUsers() {
  try {
    const stored = localStorage.getItem(USERS_KEY);
    return stored ? JSON.parse(stored) : DEFAULT_USERS;
  } catch {
    return DEFAULT_USERS;
  }
}

export function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export function getSession() {
  try {
    const stored = sessionStorage.getItem(AUTH_KEY);
    return stored ? JSON.parse(stored) : null;
  } catch {
    return null;
  }
}

export function login(username, password) {
  const users = getUsers();
  const user  = users.find(
    (u) => u.username === username.trim() && u.password === password
  );
  if (!user) return null;
  const session = { username: user.username, name: user.name, role: user.role };
  sessionStorage.setItem(AUTH_KEY, JSON.stringify(session));
  return session;
}

export function logout() {
  sessionStorage.removeItem(AUTH_KEY);
}

export function register(username, password, name) {
  const users = getUsers();
  if (users.find((u) => u.username === username.trim())) return false;
  users.push({ username: username.trim(), password, name: name.trim(), role: "user" });
  saveUsers(users);
  return true;
}
